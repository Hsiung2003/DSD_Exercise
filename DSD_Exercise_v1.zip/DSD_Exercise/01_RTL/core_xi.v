// One Gauss–Seidel row update: 20*x_i = b_i + x_{i-3} - 6*x_{i-2} + 13*x_{i-1} + 13*x_{i+1} - 6*x_{i+2} + x_{i+3}
// Q16.16 for x neighbors; b_i scaled as (b_i << 16).
//
// 3-stage pipeline (after in_valid):
//   stage1: latch operands
//   stage2: partial row sum -> r_sum
//   stage3: divide by 20 -> r_div, then register x_out / out_valid
// GSIM extends its valid/index shift by one stage (v_pipe3) so commit aligns
// with this latency.

`timescale 1ns/10ps

module core_xi (
    input wire clk,
    input wire reset,
    input wire in_valid,
    input wire signed [15:0] bi,
    input wire signed [31:0] x_im3,
    input wire signed [31:0] x_im2,
    input wire signed [31:0] x_im1,
    input wire signed [31:0] x_ip1,
    input wire signed [31:0] x_ip2,
    input wire signed [31:0] x_ip3,
    output reg out_valid,
    output reg signed [31:0] x_out
);

  reg [2:0] qv;

  reg signed [15:0] r_bi;
  reg signed [31:0] r_im3, r_im2, r_im1, r_ip1, r_ip2, r_ip3;

  reg signed [47:0] r_sum;
  reg signed [31:0] r_div;

  wire signed [47:0] w_bi_q = $signed(r_bi) <<< 16;
  wire signed [47:0] w_row =
      w_bi_q
    + $signed(r_im3)
    - ($signed(r_im2) * 48'sd6)
    + ($signed(r_im1) * 48'sd13)
    + ($signed(r_ip1) * 48'sd13)
    - ($signed(r_ip2) * 48'sd6)
    + $signed(r_ip3);

    // === DEBUG ===
  always @(posedge clk) begin
    if (out_valid) begin
      $display("[CORE %m] @%0t  x_out=%h  r_div=%h  r_sum=%h  r_bi=%d",
              $time, x_out, r_div, r_sum, r_bi);
    end
    if (in_valid) begin
      $display("[CORE %m IN] @%0t  bi=%d  xim3=%h xim2=%h xim1=%h xip1=%h xip2=%h xip3=%h",
              $time, bi, x_im3, x_im2, x_im1, x_ip1, x_ip2, x_ip3);
    end
  end
  // === END DEBUG ===
  always @(posedge clk or posedge reset) begin
    if (reset) begin
      qv <= 3'b0;
      out_valid <= 1'b0;
      x_out <= 32'sd0;
      r_bi <= 16'sd0;
      r_im3 <= 32'sd0;
      r_im2 <= 32'sd0;
      r_im1 <= 32'sd0;
      r_ip1 <= 32'sd0;
      r_ip2 <= 32'sd0;
      r_ip3 <= 32'sd0;
      r_sum <= 48'sd0;
      r_div <= 32'sd0;
    end else begin
      qv <= {qv[1:0], in_valid};

      if (in_valid) begin
        r_bi  <= bi;
        r_im3 <= x_im3;
        r_im2 <= x_im2;
        r_im1 <= x_im1;
        r_ip1 <= x_ip1;
        r_ip2 <= x_ip2;
        r_ip3 <= x_ip3;
      end

      if (qv[0]) r_sum <= w_row;

      if (qv[1]) r_div <= r_sum / 48'sd20;

      if (qv[2]) begin
        x_out     <= r_div;
        out_valid <= 1'b1;
      end else begin
        out_valid <= 1'b0;
      end
    end
  end
endmodule
